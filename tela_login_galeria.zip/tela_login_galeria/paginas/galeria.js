import {View, Text, Image, StyleSheet, Button} from 'react-native'

export default function Galeria({navigation}){
  return (
    <View style={estilos.janela}>
      <Text style={estilos.titulo}>Bem vindo(a) a galeria da Danielly Viana Santos (matrícula: 202001119876)</Text>
      <View style={estilos.foto}>
      <Image source={require('../assets/img/Danielly_Viana.png')} style={estilos.logo}></Image>
      <Button title = "Acessar o campus Parangaba" onPress={()=>navigation.navigate('Campus')}/>
      <Button title = "Acessar as disciplinas" onPress={()=>navigation.navigate('Disciplinas')}/>
      <Button title = "Acessar os livros" onPress={()=>navigation.navigate('Livros')}/>
      </View>
    </View>
  )
}
const estilos = StyleSheet.create({
  janela:{
    flex: 1,
    backgroundColor: '#87ceeb'
  },
  titulo:{
    textAlign:'center',
    fontSize: '25px',
    margin: '10px',
    color: '#800080'
  },
  foto:{
    alignSelf:'center',
    marginTop:'10px',
    borderRadius:'10px',
  },
})
