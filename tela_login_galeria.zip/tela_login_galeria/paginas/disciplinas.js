import {View, Text, Image, StyleSheet, Button} from 'react-native'

export default function Disciplinas({navigation}){
  return (
    <View style={estilos.janela}>
      <Text style={estilos.titulo}>Disciplinas cursadas</Text>
      <View style={estilos.imgGroup}> 
        <Image source={require('../assets/img/1semestre.png')} style={estilos.imagens}/>
        <Image source={require('../assets/img/2semestre.png')} style={estilos.imagens}/>
        <Image source={require('../assets/img/3semestre.png')} style={estilos.imagens}/>
        <Image source={require('../assets/img/4semestre.png')} style={estilos.imagens}/>
        <Image source={require('../assets/img/5semestre.png')} style={estilos.imagens}/>
        <Image source={require('../assets/img/6semestre.png')} style={estilos.imagens}/>        
      </View>
    </View>
  )
}

const estilos = StyleSheet.create({
  imgGroup:{
    display: 'inline-block',
  },
  janela:{
    flex: 1,
    backgroundColor: '#87ceeb'

  },
  titulo:{
    textAlign:'center',
    fontSize: '25px',
    margin: '10px',
    color: '#800080'
  },
  imagens:{
    width: 145,
    height: 130,
    margin: 5,
    display: 'inline-block',
    borderRadius: 5,
  }
})