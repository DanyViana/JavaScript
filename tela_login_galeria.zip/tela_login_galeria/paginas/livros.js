import {View, Text, Image, StyleSheet, Button} from 'react-native'

export default function Livros({navigation}){
  return (
    <View style={estilos.janela}>
      <Text style={estilos.titulo}>Livros Preferidos</Text>
      <View style={estilos.imgGroup}> 
        <Image source={require('../assets/img/livro1.JPG')} style={estilos.imagens}/>
        <Image source={require('../assets/img/livro2.JPG')} style={estilos.imagens}/>
        <Image source={require('../assets/img/livro3.JPG')} style={estilos.imagens}/>
        <Image source={require('../assets/img/livro4.JPG')} style={estilos.imagens}/>
        <Image source={require('../assets/img/livro5.JPG')} style={estilos.imagens}/>
        <Image source={require('../assets/img/livro6.JPG')} style={estilos.imagens}/>
               
      </View>
    </View>
  )
}

const estilos = StyleSheet.create({
  imgGroup:{
    display: 'inline-block',
  },
  janela:{
    flex: 1,
    backgroundColor: '#87ceeb'
  },
  titulo:{
    textAlign:'center',
    fontSize: '25px',
    margin: '10px',
    color: '#800080'
  },
  imagens:{
    width: 145,
    height: 130,
    margin: 5,
    display: 'inline-block',
    borderRadius: 5,
  }
})