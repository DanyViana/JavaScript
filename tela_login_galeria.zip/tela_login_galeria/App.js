import{NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import Home from './paginas/telaPrincipal';
import Galeria from './paginas/galeria';
import Campus from './paginas/campus';
import Disciplinas from './paginas/disciplinas';
import Livros from './paginas/livros'

const Stack = createNativeStackNavigator();

export default function App(){
  return(
    <NavigationContainer> 
      <Stack.Navigator>
        <Stack.Screen name ="Home" component = {Home}/>
        <Stack.Screen name ="Galeria" component = {Galeria}/>
        <Stack.Screen name ="Campus" component = {Campus}/>
        <Stack.Screen name ="Disciplinas" component = {Disciplinas}/>
        <Stack.Screen name ="Livros" component = {Livros}/>
      </Stack.Navigator>
    </NavigationContainer>
    );
  }