import * as React from 'react';
import {View, Text, StyleSheet, Button, Image, TextInput} from 'react-native';
import {Card} from 'react-native-paper';

export default function Home({navigation}){
  return (
    <View style={estilos.janela}>
      <View style={estilos.item_login}>
       <Image source={require('../assets/img/logo_estacio.png')} style={estilos.logo}></Image>
       <Text style={estilos.titulo}> Login da Danielly Viana </Text>
       <TextInput style={estilos.textCampo} placeholder = {'Usuário'}></TextInput>
       <TextInput style={estilos.textCampo} placeholder = {'Senha'}></TextInput>
       <Button title = "Acessar a galeria" onPress={()=>navigation.navigate('Galeria')}/>
      </View>
    </View>
  );
}

const estilos = StyleSheet.create({
  janela:{
    flex:1,
    backgroundColor:'#80bbe9',
  },
  item_login:{
    margin: '15px',
    backgroundColor: 'white',
    width: '80%',
    heigth: '80%',
    borderRadius: '10px',
  },
  titulo:{
    textAling: 'center',
    fontSize:'20px',
    marginTop:'20px',
  },
  textCampo:{
    border:'1px #256af5 solid',
    margin:'10px',
    borderRadius:'5px',
  },
  logo:{
    alignSelf:'center',
    marginTop:'10px',
    borderRadius:'10px',
  },
});
